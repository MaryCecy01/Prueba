package Prueba;
import java.util.Scanner;
public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String contra= "SIS455", intento="", us= "MaryCecy", intento1="";
		int cont=0, a=0;
		Scanner tc= new Scanner(System.in);
		
		do {
			System.out.println("Ingrese Nombre de Usuario");
			intento1=tc.nextLine();
			System.out.println("Ingrese Contraseña");
			intento=tc.nextLine();
			
			if((us.equals(intento1)) && (contra.equals(intento))) {
				System.out.println("Bienvenido");
				a=1;
				
			}else {
				System.out.println("Nombre de Usuario o Contraseña Incorrecto");
				cont++;
				if(cont==3) {
					System.out.println("Ha exedido  el numero de intentos...¡Acceso Restringido!");
					
				}
			}
		}while((cont!=3)&& a==0);
		System.out.println("Número de  Intentos: "+cont);
		
		

	}

}
